package br.com.salesha.sistemaPet.dto;

public class ProntuarioPacienteDTO {

}
