package br.com.salesha.sistemaPet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaPetApplication.class, args);
	}

}
