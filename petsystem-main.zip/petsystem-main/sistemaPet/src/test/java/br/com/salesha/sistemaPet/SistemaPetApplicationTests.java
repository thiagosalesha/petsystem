package br.com.salesha.sistemaPet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaPetApplicationTests {

	@Test
	void contextLoads() {
	}

}
